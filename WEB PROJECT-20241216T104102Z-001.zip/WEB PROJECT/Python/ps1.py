# class Programmer:
#     company = "MicroSoft"
#     def __init__(self,name,age, salary):
#         self.name = name
#         self.age = age
#         self.salary = salary

# p=Programmer("ryan",21,23435)
# print(p.company,p.name,p.age,p.salary)
# p=Programmer("harsh",31,323435)
# print(p.company,p.name,p.age,p.salary)

# class cal:
#     def __init__(self,n):
#         self.n=n
    
#     def sqaure(self):
#         print(f"{self.n*self.n}")
    
#     def cube(self):
#         print(f"{self.n*self.n*self.n}")

# a= cal(4)
# a.sqaure()
# a.cube()

# class Head:
#     a = 1

# class Programmer(Head):
#     b = 2

# class Employee(Programmer):
#     c = 3

# o = Head()
# print(o.a)