# f = open("poem.txt")
# c = f.read()
# if (c == "twinkle"):
#     print("its there")
# else:
#     print("NOT THERE")
# f.close()



# print("hello")
# with open("try.txt") as f:
#     c = f.read().strip()
#     if c == "twinkle":
#         print("It's there")
#     else:
#         print("NOT THERE")


class Employee:
    # a = 12
    # name="ryan"

    def info(self):
        print("good")

    def __init__(self):
        print("constructor will call automatically")

    def __init__(self,name,age,number):
        self.name= name
        self.age=age
        self.number = number
        print("Object Creation")

# ob = Employee()
# print(ob.a,"\n",ob.name)
# ob.info()
ob = Employee("ryan",21,7718944884)
print(ob.name,ob.age,ob.number)
