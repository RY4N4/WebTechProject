import random
n = random.randint(1,50)
a=-1
guesses = 1

while(a != n):
    a = int(input("Enter a number to guess :"))
    if a > n:
        print("Enter a Higher Number")
        guesses +=1
    elif a < n:
        print("Enter a lower number")

print(f"Number of guesses{guesses} and the Number is {n}")