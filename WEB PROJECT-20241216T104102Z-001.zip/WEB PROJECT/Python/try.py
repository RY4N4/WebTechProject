f = open("try.txt")
data = f.read()
print(data)